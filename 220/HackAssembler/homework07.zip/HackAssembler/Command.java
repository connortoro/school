public enum Command {
    A_COMMAND,
    C_COMMAND,
    L_COMMAND,
    NO_COMMAND
}